from django.contrib import admin
from .models import SearchResult

admin.site.register(SearchResult)
