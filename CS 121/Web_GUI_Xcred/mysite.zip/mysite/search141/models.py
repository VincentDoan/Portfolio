from django.db import models

class SearchResult(models.Model):
    result_url = models.CharField(max_length=200)
    result_text = models.CharField(max_length=200)
    search_str =  models.CharField(max_length=200)
