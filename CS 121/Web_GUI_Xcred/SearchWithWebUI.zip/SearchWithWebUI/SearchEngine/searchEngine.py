import json
import os
import sys

class Page:
    def __init__(self,url,txt):
        self.url = url
        self.txt = txt

dict2 = dict()
dict3 = dict()
dict4 = dict()
dict5 = dict()
dict6 = dict()

def load():
    path = r'C:\Users\Nathan\mysite\search141\SearchEngine'
    global dict2
    global dict3
    global dict4
    global dict5
    global dict6
    dict2 = dict()
    dict3 = dict()
    dict4 = dict()
    dict5 = dict()
    dict6 = dict()
    with open(os.path.join(path, 'dict2.txt'),'r') as data_file:
        dict2 = json.loads(data_file.read())

    with open(os.path.join(path, 'dict3.txt'),'r') as data_file:
        dict3 = json.loads(data_file.read())

    with open(os.path.join(path, 'dict4.txt'),'r') as data_file:
        dict4 = json.loads(data_file.read())

    with open(os.path.join(path, 'dict5.txt'),'r') as data_file:
        dict5 = json.loads(data_file.read())

    with open(os.path.join(path, 'dict6.txt'),'r') as data_file:
        dict6 = json.loads(data_file.read())

def search(terms):
    path = r'C:\Users\Nathan\Documents\School\UCI\2015_Spring\INF 141\Index\FileDump'
    global dict2
    global dict3
    global dict4
    global dict5
    global dict6

    dict7 = {}
    input = []
    list = []
    ordered_List = []

    for word in terms.split():
        if word != word.upper():
            word = word.lower()
        input.append(word)

    #This part scores URLs based on TF-IDF
    for word in input:
        try:
            for url in dict2[word]:
                try:
                    dict7[url] += dict6[url][word] #* dict5[url]
                except:
                    dict7[url] = dict6[url][word] #* dict5[url]
            for url in dict7:
                if word not in dict6[url]:
                    dict7[url] *= .1
        except:
            pass

    #This part Scores URLs based on appearence of keyterms in the title
    count = 1
    for url in dict7:
        for word in input:
            if word not in dict4[url]:
                count *= .5
        dict7[url] = (dict7[url] * .25) + (count * .75)
        count = 1

    list = sorted(dict7, key=dict7.get, reverse=True)
    if len(list) < 5:
        length = len(list)
    else:
        length = 5
    for i in range(0,length):
        try:
            #get json file of url
            txt = ''
            file_name = str(dict3[list[i]]) + '.txt'
            data_file = open(os.path.join(path, file_name),'r')
            file = json.loads(data_file.read())

            #save body of text in a list
            text = []
            for word in file['text'].split():
                text.append(word)

            #save URl and 1st instance of term + next 15 words in page object
            j = 0
            for word in text:
                if word in input:
                    print("word= {} input={} j={}".format(word,input,j))
                    try:
                        track = j
                        while track < j+15:
                            txt += text[track] + " "
                            print("in while: txt={} j={}".format(txt,j))
                            track += 1
                        break
                    except:
                        continue
                j += 1
            ordered_List.append(Page(list[i], txt))
        except IndexError:
            continue
    return ordered_List

if __name__ == "__main__":
    load()
    for i in search("student affairs"):
        print(i.url)
        print(i.txt)
    print(len(search("asdf")))
    for i in search("mondego"):
        print(i.url)
        print(i.txt)