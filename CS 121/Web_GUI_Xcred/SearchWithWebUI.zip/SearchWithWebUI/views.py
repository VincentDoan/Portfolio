from django.http import HttpResponse, HttpResponseRedirect
from django.template import RequestContext, loader
from django.shortcuts import render, redirect
from search141.SearchEngine import searchEngine

class Result():
    def __init__(self, url, txt):
        self.url = url
        self.txt = txt
        pass

    def getUrl(self):
        return self.url

    def getTxt(self):
        return self.txt

searchResults = []


def index(request):
    global searchResults
    searchResults = []
    searchEngine.load()
    return HttpResponse(render(request, 'search141/index.html'))

def handleSearch(request):
    global searchResults
    searchResults = []
    search_txt = request.POST["searchParamStr"]
    #print(search_txt)
    searchResults = searchEngine.search(search_txt)
    """
    if len(searchResults) > 0:
        for i in searchResults:
            print(i.url)

    if request.method != "POST":
        search_txt = "No instance of POST"
    else:
        search_txt = request.POST["searchParamStr"]
        global  searchResults
        searchResults.append(Result("www.google.com", "Hi"))
        searchResults.append(Result("www.bing.com", "there"))
        searchResults.append(Result("www.yahoo.com", "I'm"))
        searchResults.append(Result("www.amazon.com", "Nathan"))
    """
    return redirect('search141:results')

def results(request):
    global searchResults
    return HttpResponse(render(request, 'search141/results.html', {'searchResults':searchResults}))